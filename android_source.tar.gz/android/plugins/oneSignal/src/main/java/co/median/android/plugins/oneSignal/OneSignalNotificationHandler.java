package co.median.android.plugins.oneSignal;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import com.onesignal.OSNotification;
import com.onesignal.OSNotificationOpenedResult;
import com.onesignal.OneSignal;

import org.json.JSONObject;

import co.median.median_core.GoNativeActivity;
import co.median.median_core.LeanUtils;

/**
 * Created by weiyin on 2/10/16.
 */
public class OneSignalNotificationHandler implements OneSignal.OSNotificationOpenedHandler {

    private static final String TAG = OneSignalNotificationHandler.class.getName();
    public static final String INTENT_TARGET_URL = "targetUrl";
    private static final String CALLBACK_PUSH_OPENED = "median_onesignal_push_opened";
    private static final String CALLBACK_PUSH_OPENED_LEGACY = "gonative_onesignal_push_opened";
    private static final String CALLBACK_PUSH_OPENED_NPM = "_median_onesignal_push_opened";
    private Activity activity;
    private boolean isPageReady = false;
    private boolean injectMedianJS = true;

    @SuppressWarnings("unused")
    public OneSignalNotificationHandler() {
        // default construct needed to be a broadcast receiver
    }

    OneSignalNotificationHandler(Activity activity, boolean injectMedianJS) {
        this.activity = activity;
        this.injectMedianJS = injectMedianJS;
    }

    public void initialPageReady() {
        if (isPageReady || !injectMedianJS) return;
        this.isPageReady = true;
        subscribe(CALLBACK_PUSH_OPENED);
        subscribe(CALLBACK_PUSH_OPENED_LEGACY);
    }

    @Override
    public void notificationOpened(OSNotificationOpenedResult openedResult) {
        OSNotification notification = openedResult.getNotification();
        
        String launchUrl = notification.getLaunchURL();
        if (launchUrl != null && !launchUrl.isEmpty()) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(launchUrl));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            activity.startActivity(intent);
            return;
        }
        
        JSONObject additionalData = notification.getAdditionalData();
        String targetUrl = LeanUtils.optString(additionalData, INTENT_TARGET_URL);

        if (!TextUtils.isEmpty(targetUrl)) {
            launchMainActivity(targetUrl);
            return;
        }

        handleNotificationDataCallback(additionalData);
    }

    private void handleNotificationDataCallback(JSONObject data) {
        if (injectMedianJS) {
            invokeCallback(CALLBACK_PUSH_OPENED, data);
            invokeCallback(CALLBACK_PUSH_OPENED_LEGACY, data);
        } else {
            invokeCallback(CALLBACK_PUSH_OPENED_NPM, data);
        }
    }

    private void subscribe(String callback) {
        if (activity == null) return;
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).subscribeEvent(callback);
        }
    }

    private void invokeCallback(String callback, JSONObject data) {
        if (activity == null) return;
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).invokeCallback(callback, data);
        }
    }

    private void launchMainActivity(String url) {
        if (activity == null) return;
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).launchNotificationActivity(url);
        }
    }
}
