// "Add to Cart" Enhancement
document.querySelectorAll('.add-to-cart-button').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default action
        const productId = this.dataset.productId; // Assuming product ID is stored in data attribute

        // Update cart without navigating away
        updateCart(productId);
    });
});

function updateCart(productId) {
    // Existing cart update logic (e.g., AJAX call to update cart)
    console.log(`Product ${productId} added to cart.`);
    // Update cart icon logic here if necessary
}

// Loading Progress Bar
const loadingBarContainer = document.getElementById('loading-bar-container');
const loadingBar = document.getElementById('loading-bar');

document.addEventListener('click', function(event) {
    if (event.target.matches('.trigger-loading')) { // Adjust selector as needed
        loadingBarContainer.style.display = 'block'; // Show progress bar
        loadingBar.style.width = '90%'; // Animate to 90%
        
        setTimeout(() => {
            loadingBar.style.width = '100%'; // Animate to 100%
            setTimeout(() => {
                loadingBarContainer.style.display = 'none'; // Hide after loading
                loadingBar.style.width = '0%'; // Reset width
            }, 500); // Adjust duration as needed
        }, 2000); // Simulate loading time
    }
});

// Lazy Loading for Images
const lazyLoadImages = document.querySelectorAll('img[data-src]');
const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src; // Set the actual image source
            img.onload = () => img.removeAttribute('data-src'); // Remove data-src attribute
            observer.unobserve(img); // Stop observing the image
        }
    });
});

lazyLoadImages.forEach(image => {
    imageObserver.observe(image); // Observe each lazy load image
});